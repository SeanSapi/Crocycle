<?php

include "../connection.php";

session_start();

if (isset($_POST[""])) {
    $product_id = (int)$_POST['product_id'];

}

?>